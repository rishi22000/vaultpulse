Acme Corp Brand Assets Master Bundle
Includes SVG logos, color palettes, typography specs.